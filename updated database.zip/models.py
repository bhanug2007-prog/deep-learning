"""
database/models.py
──────────────────────────────────────────────────────────────
Phase 2 — SQLAlchemy ORM Models
6 tables matching schema.sql exactly
──────────────────────────────────────────────────────────────
"""

import os
from datetime import datetime
from dotenv import load_dotenv

from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean,
    ForeignKey, TIMESTAMP, create_engine
)
from sqlalchemy.orm import relationship, DeclarativeBase, Session
from sqlalchemy.sql import func

load_dotenv()


# ─────────────────────────────────────────────
# Base class
# ─────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ─────────────────────────────────────────────
# TABLE 1: students
# ─────────────────────────────────────────────
class Student(Base):
    __tablename__ = "students"

    student_id   = Column(Integer, primary_key=True, autoincrement=True)
    student_name = Column(String(150), nullable=False)
    roll_number  = Column(String(50),  nullable=False, unique=True)
    created_at   = Column(TIMESTAMP,   server_default=func.now())

    # Relationships
    answer_sheets = relationship(
        "AnswerSheet",
        back_populates="student",
        cascade="all, delete"
    )

    def __repr__(self):
        return f"<Student {self.roll_number}: {self.student_name}>"


# ─────────────────────────────────────────────
# TABLE 2: exams
# ─────────────────────────────────────────────
class Exam(Base):
    __tablename__ = "exams"

    exam_id             = Column(Integer, primary_key=True, autoincrement=True)
    subject_name        = Column(String(150), nullable=False)
    exam_name           = Column(String(150), nullable=False)
    total_marks         = Column(Integer,     nullable=False)
    number_of_questions = Column(Integer,     nullable=False)
    created_at          = Column(TIMESTAMP,   server_default=func.now())

    # Relationships
    questions     = relationship(
        "Question",
        back_populates="exam",
        cascade="all, delete"
    )
    answer_sheets = relationship(
        "AnswerSheet",
        back_populates="exam",
        cascade="all, delete"
    )

    def __repr__(self):
        return f"<Exam {self.exam_id}: {self.exam_name} | {self.subject_name}>"


# ─────────────────────────────────────────────
# TABLE 3: questions
# ─────────────────────────────────────────────
class Question(Base):
    __tablename__ = "questions"

    question_id     = Column(Integer, primary_key=True, autoincrement=True)
    exam_id         = Column(Integer, ForeignKey("exams.exam_id"), nullable=False)
    question_number = Column(Integer, nullable=False)
    question_text   = Column(Text,    nullable=False)
    model_answer    = Column(Text,    nullable=False)
    keywords        = Column(Text)        # comma-separated keyword string
    max_marks       = Column(Integer,     nullable=False)

    # Relationships
    exam            = relationship("Exam",    back_populates="questions")
    student_answers = relationship(
        "StudentAnswer",
        back_populates="question",
        cascade="all, delete"
    )

    def keywords_list(self) -> list[str]:
        """Return keywords as a Python list."""
        if not self.keywords:
            return []
        return [k.strip() for k in self.keywords.split(",") if k.strip()]

    def __repr__(self):
        return f"<Question {self.question_number} | Exam {self.exam_id}: {self.question_text[:50]}>"


# ─────────────────────────────────────────────
# TABLE 4: answer_sheets
# ─────────────────────────────────────────────
class AnswerSheet(Base):
    __tablename__ = "answer_sheets"

    sheet_id    = Column(Integer,      primary_key=True, autoincrement=True)
    student_id  = Column(Integer,      ForeignKey("students.student_id"), nullable=False)
    exam_id     = Column(Integer,      ForeignKey("exams.exam_id"),       nullable=False)
    file_path   = Column(String(255),  nullable=False)
    upload_time = Column(TIMESTAMP,    server_default=func.now())

    # Relationships
    student         = relationship("Student", back_populates="answer_sheets")
    exam            = relationship("Exam",    back_populates="answer_sheets")
    student_answers = relationship(
        "StudentAnswer",
        back_populates="answer_sheet",
        cascade="all, delete"
    )

    def __repr__(self):
        return f"<AnswerSheet {self.sheet_id} | Student {self.student_id} | Exam {self.exam_id}>"


# ─────────────────────────────────────────────
# TABLE 5: student_answers
# ─────────────────────────────────────────────
class StudentAnswer(Base):
    __tablename__ = "student_answers"

    answer_id      = Column(Integer, primary_key=True, autoincrement=True)
    sheet_id       = Column(Integer, ForeignKey("answer_sheets.sheet_id"),  nullable=False)
    question_id    = Column(Integer, ForeignKey("questions.question_id"),   nullable=False)
    extracted_text = Column(Text)   # OCR output stored here

    # Relationships
    answer_sheet       = relationship("AnswerSheet", back_populates="student_answers")
    question           = relationship("Question",    back_populates="student_answers")
    evaluation_result  = relationship(
        "EvaluationResult",
        back_populates="student_answer",
        uselist=False,
        cascade="all, delete"
    )

    def __repr__(self):
        return f"<StudentAnswer {self.answer_id} | Sheet {self.sheet_id} | Q{self.question_id}>"


# ─────────────────────────────────────────────
# TABLE 6: evaluation_results
# ─────────────────────────────────────────────
class EvaluationResult(Base):
    __tablename__ = "evaluation_results"

    result_id       = Column(Integer,   primary_key=True, autoincrement=True)
    answer_id       = Column(Integer,   ForeignKey("student_answers.answer_id"),
                             nullable=False, unique=True)
    semantic_score  = Column(Float,     nullable=False)   # 0.0 – 1.0
    keyword_score   = Column(Float,     nullable=False)   # 0.0 – 1.0
    final_marks     = Column(Float,     nullable=False)   # actual marks awarded
    manual_override = Column(Boolean,   default=False)    # TRUE when teacher edits marks
    evaluated_at    = Column(TIMESTAMP, server_default=func.now())

    # Relationships
    student_answer = relationship("StudentAnswer", back_populates="evaluation_result")

    def __repr__(self):
        override = " [MANUAL]" if self.manual_override else ""
        return (
            f"<EvaluationResult {self.result_id} | "
            f"semantic={self.semantic_score:.2f} | "
            f"keyword={self.keyword_score:.2f} | "
            f"marks={self.final_marks}{override}>"
        )


# ─────────────────────────────────────────────
# Database engine + session
# ─────────────────────────────────────────────
def get_engine(database_url: str | None = None):
    url = database_url or os.getenv(
        "DATABASE_URL",
        "mysql+pymysql://root:password@localhost:3306/ai_evaluation_db"
    )
    return create_engine(url, pool_pre_ping=True, echo=False)


def init_db(database_url: str | None = None):
    """Create all tables in the database."""
    engine = get_engine(database_url)
    Base.metadata.create_all(engine)
    print("✅  All 6 tables created successfully.")
    return engine


def get_session(engine) -> Session:
    """Return a new database session."""
    from sqlalchemy.orm import sessionmaker
    SessionLocal = sessionmaker(bind=engine)
    return SessionLocal()


# ─────────────────────────────────────────────
# Quick test
# ─────────────────────────────────────────────
if __name__ == "__main__":
    print("Tables defined:")
    for table in Base.metadata.sorted_tables:
        print(f"  ✅  {table.name}")
