-- ============================================================
-- AI Answer Evaluation System
-- Phase 2 — Database Design
-- 6 Tables | MySQL 8.0+
-- ============================================================
-- WORKFLOW:
-- Teacher uploads question paper  → exams + questions
-- Assistant uploads answer sheet  → answer_sheets
-- OCR extracts text               → student_answers
-- AI evaluates answers            → evaluation_results
-- Frontend shows results          → students + evaluation_results
-- ============================================================

CREATE DATABASE IF NOT EXISTS ai_evaluation_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ai_evaluation_db;

-- ============================================================
-- TABLE 1: students
-- Stores student information
-- Who submitted which answer sheet
-- ============================================================
CREATE TABLE IF NOT EXISTS students (
    student_id   INT           PRIMARY KEY AUTO_INCREMENT,
    student_name VARCHAR(150)  NOT NULL,
    roll_number  VARCHAR(50)   NOT NULL UNIQUE,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 2: exams
-- Stores question paper uploaded by teacher
-- One row = one question paper / exam
-- ============================================================
CREATE TABLE IF NOT EXISTS exams (
    exam_id              INT          PRIMARY KEY AUTO_INCREMENT,
    subject_name         VARCHAR(150) NOT NULL,
    exam_name            VARCHAR(150) NOT NULL,
    total_marks          INT          NOT NULL,
    number_of_questions  INT          NOT NULL,
    created_at           TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 3: questions
-- Stores each question belonging to an exam
-- Includes model answer, keywords, max marks
-- ============================================================
CREATE TABLE IF NOT EXISTS questions (
    question_id     INT      PRIMARY KEY AUTO_INCREMENT,
    exam_id         INT      NOT NULL,
    question_number INT      NOT NULL,
    question_text   TEXT     NOT NULL,
    model_answer    TEXT     NOT NULL,
    keywords        TEXT,
    max_marks       INT      NOT NULL,

    FOREIGN KEY (exam_id)
        REFERENCES exams(exam_id)
        ON DELETE CASCADE
);

-- ============================================================
-- TABLE 4: answer_sheets
-- Stores uploaded student answer sheet file path
-- Links student ↔ exam
-- ============================================================
CREATE TABLE IF NOT EXISTS answer_sheets (
    sheet_id    INT          PRIMARY KEY AUTO_INCREMENT,
    student_id  INT          NOT NULL,
    exam_id     INT          NOT NULL,
    file_path   VARCHAR(255) NOT NULL,
    upload_time TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
        REFERENCES students(student_id)
        ON DELETE CASCADE,

    FOREIGN KEY (exam_id)
        REFERENCES exams(exam_id)
        ON DELETE CASCADE
);

-- ============================================================
-- TABLE 5: student_answers
-- Stores OCR extracted text per question per sheet
-- Image → OCR → Text stored here
-- ============================================================
CREATE TABLE IF NOT EXISTS student_answers (
    answer_id      INT  PRIMARY KEY AUTO_INCREMENT,
    sheet_id       INT  NOT NULL,
    question_id    INT  NOT NULL,
    extracted_text TEXT,

    FOREIGN KEY (sheet_id)
        REFERENCES answer_sheets(sheet_id)
        ON DELETE CASCADE,

    FOREIGN KEY (question_id)
        REFERENCES questions(question_id)
        ON DELETE CASCADE
);

-- ============================================================
-- TABLE 6: evaluation_results
-- Stores AI evaluation scores per student answer
-- semantic_score + keyword_score → final_marks
-- manual_override = TRUE when teacher edits marks manually
-- ============================================================
CREATE TABLE IF NOT EXISTS evaluation_results (
    result_id       INT       PRIMARY KEY AUTO_INCREMENT,
    answer_id       INT       NOT NULL UNIQUE,
    semantic_score  FLOAT     NOT NULL,
    keyword_score   FLOAT     NOT NULL,
    final_marks     FLOAT     NOT NULL,
    manual_override BOOLEAN   DEFAULT FALSE,
    evaluated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (answer_id)
        REFERENCES student_answers(answer_id)
        ON DELETE CASCADE
);

-- ============================================================
-- INDEXES — for faster queries on frontend dashboard
-- ============================================================
CREATE INDEX idx_questions_exam       ON questions(exam_id);
CREATE INDEX idx_sheets_student       ON answer_sheets(student_id);
CREATE INDEX idx_sheets_exam          ON answer_sheets(exam_id);
CREATE INDEX idx_answers_sheet        ON student_answers(sheet_id);
CREATE INDEX idx_answers_question     ON student_answers(question_id);
CREATE INDEX idx_results_answer       ON evaluation_results(answer_id);

-- ============================================================
-- SAMPLE SEED DATA
-- ============================================================

-- Students
INSERT INTO students (student_name, roll_number) VALUES
  ('Rahul Sharma',  '21CS045'),
  ('Priya Patel',   '21CS046'),
  ('Arjun Kumar',   '21CS047');

-- Exams
INSERT INTO exams (subject_name, exam_name, total_marks, number_of_questions) VALUES
  ('Biology',          'Biology Mid-Term 1',    50, 5),
  ('Computer Science', 'CS Unit Test 1',        30, 3),
  ('Physics',          'Physics Final Exam',   100, 10);

-- Questions for Biology Mid-Term 1 (exam_id = 1)
INSERT INTO questions (exam_id, question_number, question_text, model_answer, keywords, max_marks) VALUES
  (1, 1,
   'Explain the process of photosynthesis.',
   'Photosynthesis is the process by which green plants use sunlight to synthesize nutrients from carbon dioxide and water. It occurs in the chloroplasts using chlorophyll pigment. The process has two stages: light-dependent reactions producing ATP and NADPH, and the Calvin cycle producing glucose.',
   'chlorophyll, sunlight, carbon dioxide, water, glucose, ATP, Calvin cycle, chloroplasts',
   10),

  (1, 2,
   'What is the difference between mitosis and meiosis?',
   'Mitosis produces two genetically identical daughter cells used for growth and repair. Meiosis produces four genetically unique haploid cells used for sexual reproduction. Mitosis involves one division while meiosis involves two divisions.',
   'mitosis, meiosis, cell division, haploid, diploid, chromosome, daughter cells',
   10),

  (1, 3,
   'Describe the structure and function of DNA.',
   'DNA is a double helix structure made of nucleotides. Each nucleotide contains a sugar, phosphate group, and nitrogenous base. The four bases are Adenine, Thymine, Guanine, Cytosine. DNA stores genetic information and directs protein synthesis.',
   'double helix, nucleotide, adenine, thymine, guanine, cytosine, genetic information',
   10);

-- Questions for CS Unit Test 1 (exam_id = 2)
INSERT INTO questions (exam_id, question_number, question_text, model_answer, keywords, max_marks) VALUES
  (2, 1,
   'Explain binary search algorithm with time complexity.',
   'Binary search finds a target in a sorted array by repeatedly dividing the search space in half. It compares the target with the middle element. If equal, search ends. If smaller, search left half. If larger, search right half. Time complexity is O(log n).',
   'binary search, sorted array, O(log n), divide and conquer, middle element, logarithmic',
   10),

  (2, 2,
   'What is a linked list? Explain its types.',
   'A linked list is a linear data structure where elements are stored in nodes. Each node contains data and a pointer to the next node. Types include: Singly linked list (one direction), Doubly linked list (both directions), Circular linked list (last node points to first).',
   'linked list, node, pointer, singly, doubly, circular',
   10);
