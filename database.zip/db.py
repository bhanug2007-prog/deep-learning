"""
database/db.py
──────────────────────────────────────────────────────────────
Phase 2 — Database Connection + CRUD Operations
Used by backend API routes
──────────────────────────────────────────────────────────────
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from dotenv import load_dotenv
from database.models import (
    Base, Student, Exam, Question,
    AnswerSheet, StudentAnswer, EvaluationResult
)

load_dotenv()

# ─────────────────────────────────────────────
# Engine + Session setup
# ─────────────────────────────────────────────
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "mysql+pymysql://root:password@localhost:3306/ai_evaluation_db"
)

engine       = create_engine(DATABASE_URL, pool_pre_ping=True, echo=False)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


def get_db():
    """FastAPI dependency — yields a DB session, closes after request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ─────────────────────────────────────────────
# STUDENT CRUD
# ─────────────────────────────────────────────
def create_student(db: Session, name: str, roll: str) -> Student:
    student = Student(student_name=name, roll_number=roll)
    db.add(student)
    db.commit()
    db.refresh(student)
    return student


def get_student_by_roll(db: Session, roll: str) -> Student | None:
    return db.query(Student).filter(Student.roll_number == roll).first()


def get_all_students(db: Session) -> list[Student]:
    return db.query(Student).all()


# ─────────────────────────────────────────────
# EXAM CRUD
# ─────────────────────────────────────────────
def create_exam(db: Session, subject: str, name: str,
                total_marks: int, num_questions: int) -> Exam:
    exam = Exam(
        subject_name        = subject,
        exam_name           = name,
        total_marks         = total_marks,
        number_of_questions = num_questions
    )
    db.add(exam)
    db.commit()
    db.refresh(exam)
    return exam


def get_exam(db: Session, exam_id: int) -> Exam | None:
    return db.query(Exam).filter(Exam.exam_id == exam_id).first()


def get_all_exams(db: Session) -> list[Exam]:
    return db.query(Exam).all()


# ─────────────────────────────────────────────
# QUESTION CRUD
# ─────────────────────────────────────────────
def create_question(db: Session, exam_id: int, q_number: int,
                    q_text: str, model_answer: str,
                    keywords: str, max_marks: int) -> Question:
    question = Question(
        exam_id         = exam_id,
        question_number = q_number,
        question_text   = q_text,
        model_answer    = model_answer,
        keywords        = keywords,
        max_marks       = max_marks
    )
    db.add(question)
    db.commit()
    db.refresh(question)
    return question


def get_questions_by_exam(db: Session, exam_id: int) -> list[Question]:
    return db.query(Question).filter(Question.exam_id == exam_id).all()


# ─────────────────────────────────────────────
# ANSWER SHEET CRUD
# ─────────────────────────────────────────────
def create_answer_sheet(db: Session, student_id: int,
                        exam_id: int, file_path: str) -> AnswerSheet:
    sheet = AnswerSheet(
        student_id = student_id,
        exam_id    = exam_id,
        file_path  = file_path
    )
    db.add(sheet)
    db.commit()
    db.refresh(sheet)
    return sheet


def get_sheets_by_student(db: Session, student_id: int) -> list[AnswerSheet]:
    return db.query(AnswerSheet).filter(
        AnswerSheet.student_id == student_id
    ).all()


# ─────────────────────────────────────────────
# STUDENT ANSWER CRUD (OCR Output)
# ─────────────────────────────────────────────
def save_extracted_answer(db: Session, sheet_id: int,
                          question_id: int, text: str) -> StudentAnswer:
    answer = StudentAnswer(
        sheet_id       = sheet_id,
        question_id    = question_id,
        extracted_text = text
    )
    db.add(answer)
    db.commit()
    db.refresh(answer)
    return answer


def get_answers_by_sheet(db: Session, sheet_id: int) -> list[StudentAnswer]:
    return db.query(StudentAnswer).filter(
        StudentAnswer.sheet_id == sheet_id
    ).all()


# ─────────────────────────────────────────────
# EVALUATION RESULT CRUD
# ─────────────────────────────────────────────
def save_evaluation(db: Session, answer_id: int, semantic: float,
                    keyword: float, final: float) -> EvaluationResult:
    result = EvaluationResult(
        answer_id      = answer_id,
        semantic_score = round(semantic, 4),
        keyword_score  = round(keyword,  4),
        final_marks    = round(final,    2)
    )
    db.add(result)
    db.commit()
    db.refresh(result)
    return result


def get_results_by_student_exam(db: Session, student_id: int,
                                exam_id: int) -> list[dict]:
    """
    Returns full results for a student in a given exam.
    Used by the frontend results dashboard.
    """
    rows = (
        db.query(
            Question.question_number,
            Question.question_text,
            Question.max_marks,
            StudentAnswer.extracted_text,
            EvaluationResult.semantic_score,
            EvaluationResult.keyword_score,
            EvaluationResult.final_marks,
            EvaluationResult.evaluated_at
        )
        .join(AnswerSheet,     AnswerSheet.exam_id    == exam_id)
        .join(StudentAnswer,   StudentAnswer.sheet_id == AnswerSheet.sheet_id)
        .join(Question,        Question.question_id   == StudentAnswer.question_id)
        .join(EvaluationResult, EvaluationResult.answer_id == StudentAnswer.answer_id)
        .filter(AnswerSheet.student_id == student_id)
        .all()
    )
    return [
        {
            "question_number": r[0],
            "question_text":   r[1],
            "max_marks":       r[2],
            "student_answer":  r[3],
            "semantic_score":  r[4],
            "keyword_score":   r[5],
            "final_marks":     r[6],
            "evaluated_at":    str(r[7])
        }
        for r in rows
    ]
